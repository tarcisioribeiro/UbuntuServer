```txt
List information about the FILEs with ICONS and GIT STATUS (the current dir 
by default). Sort entries alphabetically if none of -tvSUX is specified.
Usage: logo-ls [-1?aAcdDgGhiloRrSstUvVX] [-T value] [files ...]
 -1                list one file per line.
 -?, --help        display this help and exit
 -a, --all         do not ignore entries starting with .
 -A, --almost-all  do not list implied . and ..
 -c, --disable-color
                   don't color icons, filenames and git status (use this to
                   print to a file)
 -d, --directory   list directories themselves, not their contents
 -D, --git-status  print git status of files
 -g                like -l, but do not list owner
 -G, --no-group    in a long listing, don't print group names
 -h, --human-readable
                   with -l and -s, print sizes like 1K 234M 2G etc.
 -i, --disable-icon
                   don't print icons of the files
 -l                use a long listing format
 -o                like -l, but do not list group information
 -R, --recursive   list subdirectories recursively
 -r, --reverse     reverse order while sorting
 -S                sort by file size, largest first
 -s, --size        print the allocated size of each file, in blocks
 -t                sort by modification time, newest first
 -T, --time-style=value
                   time/date format with -l; see time-style below [Stamp]
 -U                do not sort; list entries in directory order
 -v                natural sort of (version) numbers within text
 -V, --version     output version information and exit
 -X                sort alphabetically by entry extension

Possible value for --time-style (-T)
 ANSIC       "Mon Jan _2 15:04:05 2006"      
 UnixDate    "Mon Jan _2 15:04:05 MST 2006"  
 RubyDate    "Mon Jan 02 15:04:05 -0700 2006"
 RFC822      "02 Jan 06 15:04 MST"           
 RFC822Z     "02 Jan 06 15:04 -0700"         
 RFC850      "Monday, 02-Jan-06 15:04:05 MST"
 RFC1123     "Mon, 02 Jan 2006 15:04:05 MST" 
 RFC1123Z    "Mon, 02 Jan 2006 15:04:05 -0700"
 RFC3339     "2006-01-02T15:04:05Z07:00"     
 Kitchen     "3:04PM"                        
 Stamp       "Mon Jan _2 15:04:05"            [Default]
 StampMilli  "Jan _2 15:04:05.000"           

Exit status:
 0  if OK,
 1  if minor problems (e.g., cannot access subdirectory),
 2  if serious trouble (e.g., cannot access command-line argument).
```
